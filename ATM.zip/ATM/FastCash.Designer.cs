﻿namespace ATM
{
    partial class FastCash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            label2 = new Label();
            button7 = new Button();
            panel2 = new Panel();
            button5 = new Button();
            button6 = new Button();
            button3 = new Button();
            button4 = new Button();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            BlanceLbl = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateGray;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1055, 117);
            panel1.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft YaHei UI", 22F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(221, 29);
            label1.Name = "label1";
            label1.Size = new Size(612, 58);
            label1.TabIndex = 3;
            label1.Text = "ATM Management System";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft YaHei UI", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(985, 5);
            label2.Name = "label2";
            label2.Size = new Size(66, 69);
            label2.TabIndex = 2;
            label2.Text = "X";
            label2.Click += label2_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkSlateGray;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.Location = new Point(442, 744);
            button7.Name = "button7";
            button7.Size = new Size(147, 64);
            button7.TabIndex = 25;
            button7.Text = "Back";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateGray;
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 834);
            panel2.Name = "panel2";
            panel2.Size = new Size(1055, 16);
            panel2.TabIndex = 24;
            // 
            // button5
            // 
            button5.BackColor = Color.DarkSlateGray;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(608, 564);
            button5.Name = "button5";
            button5.Size = new Size(276, 64);
            button5.TabIndex = 23;
            button5.Text = "Tk: 10000";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.DarkSlateGray;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Location = new Point(144, 564);
            button6.Name = "button6";
            button6.Size = new Size(276, 64);
            button6.TabIndex = 22;
            button6.Text = "Tk: 5000";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkSlateGray;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(608, 393);
            button3.Name = "button3";
            button3.Size = new Size(276, 64);
            button3.TabIndex = 21;
            button3.Text = "Tk: 2000";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.DarkSlateGray;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(144, 393);
            button4.Name = "button4";
            button4.Size = new Size(276, 64);
            button4.TabIndex = 20;
            button4.Text = "Tk: 1000";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkSlateGray;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(608, 219);
            button2.Name = "button2";
            button2.Size = new Size(276, 64);
            button2.TabIndex = 19;
            button2.Text = "Tk: 500";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkSlateGray;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft YaHei UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(144, 219);
            button1.Name = "button1";
            button1.Size = new Size(276, 64);
            button1.TabIndex = 18;
            button1.Text = "Tk: 100";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Font = new Font("Microsoft YaHei UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.DarkSlateGray;
            label4.Location = new Point(427, 129);
            label4.Name = "label4";
            label4.Size = new Size(191, 47);
            label4.TabIndex = 40;
            label4.Text = "Fast Cash";
            // 
            // BlanceLbl
            // 
            BlanceLbl.AutoSize = true;
            BlanceLbl.BackColor = SystemColors.Control;
            BlanceLbl.Font = new Font("Microsoft YaHei UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BlanceLbl.ForeColor = Color.DarkSlateGray;
            BlanceLbl.Location = new Point(388, 318);
            BlanceLbl.Name = "BlanceLbl";
            BlanceLbl.Size = new Size(256, 47);
            BlanceLbl.TabIndex = 41;
            BlanceLbl.Text = "Available Bal";
            BlanceLbl.Click += label3_Click;
            // 
            // FastCash
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1055, 850);
            Controls.Add(BlanceLbl);
            Controls.Add(label4);
            Controls.Add(panel1);
            Controls.Add(button7);
            Controls.Add(panel2);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button3);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FastCash";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FastCash";
            Load += FastCash_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label2;
        private Button button7;
        private Panel panel2;
        private Button button5;
        private Button button6;
        private Button button3;
        private Button button4;
        private Button button2;
        private Button button1;
        private Label label1;
        private Label label4;
        private Label BlanceLbl;
    }
}